import requests
from geopy import geocoders


class Weather():
    __api_key = '58e3e995-5cb3-4899-aec7-8ffa67fa668d'

    def __init__(self, city='Москва'):
        self.city = city

    def geo_pos(self):
        # метод для определения координат в градусах по названию города
        geolocator = geocoders.Nominatim(user_agent="telebot")
        latitude = str(geolocator.geocode(self.city).latitude)
        longitude = str(geolocator.geocode(self.city).longitude)
        return latitude, longitude

    def get_temperature(self):
        # получаем данные из апи Яндекс погоды
        latitude, longitude = self.geo_pos()
        api_url = f'https://api.weather.yandex.ru/v2/forecast/?lat={latitude}&lon={longitude}&[lang=ru_RU]'
        params = {'X-Yandex-API-Key': self.__api_key}
        res = requests.get(api_url, headers=params).json()
        return res['fact']['temp']

    def get_data(self):
        # получаем данные из апи Яндекс погоды
        latitude, longitude = self.geo_pos()
        api_url = f'https://api.weather.yandex.ru/v2/forecast/?lat={latitude}&lon={longitude}&[lang=ru_RU]'
        params = {'X-Yandex-API-Key': self.__api_key}
        res = requests.get(api_url, headers=params).json()
        return res
