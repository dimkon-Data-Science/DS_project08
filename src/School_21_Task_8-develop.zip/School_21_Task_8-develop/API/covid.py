import requests
import json


class COVID():

    def __init__(self, country='Russia'):
        self.country = country

    def get_cases(self):
        # получаем данные из апи COVID-19
        api_covid = 'https://covid-api.mmediagroup.fr/v1/cases'
        params = {'country': self.country}
        res = requests.get(api_covid, params=params).json()
        # возвращаем строку в формате json
        return res['All']['confirmed']

    def get_data(self):
        api_covid = 'https://covid-api.mmediagroup.fr/v1/cases'
        res = requests.get(api_covid).json()
        return res

    def get_history(self):
        api_covid = 'https://covid-api.mmediagroup.fr/v1/history'
        params = {
            'status': 'Confirmed',  # 'Deaths'
        }
        res = requests.get(api_covid, params=params).json()
        return "NotImplemented. You have to parse data."
