import aiohttp


class Image():
    async def get_image_url(self, collections=None):
        url = 'https://api.unsplash.com/photos/random?client_id=0WFgkAcPaQN54A4ZUELi1ZfT3LyBZK_8FEMyVm7aLL0&query'
        if collections:
            url = url + '&query=' + collections
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data['urls']['raw']
                return f"Something went wrong. Response status: {resp.status}"
