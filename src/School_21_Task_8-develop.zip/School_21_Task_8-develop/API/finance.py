import requests


class Finance():

    def __init__(self, currency='usd'):
        self.currency = str.upper(currency)

    def get_rate(self):
        api_cbr = 'https://www.cbr-xml-daily.ru/daily_json.js'
        res = requests.get(api_cbr)
        data = res.json()
        return data['Valute'][self.currency]['Value'] / data['Valute'][self.currency]['Nominal']

    def get_data(self):
        api_cbr = 'https://www.cbr-xml-daily.ru/daily_json.js'
        res = requests.get(api_cbr)
        data = res.json()
        return data['Valute']
