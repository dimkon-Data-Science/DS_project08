settings = {
    'token': 'MTAxNDIzNzExNzUyMzcxMDEwMw.Ghad6B.mYgItWuYVQlCTBk1WrrFG8qYzMvRDEKmYGhow0',
    'token_gendellu': 'MTAxNDIxNzg0NjMwMzI0ODQzNQ.GIQUmN.81NqS1EXSxuRF9V6H_c_E_VoQwRghzPyaBQ5Bg',
    'bot': 'ds08_bot1',
    'id': 1014237117523710103,
    'prefix': '#',
    'path_model': 'D:/0Dev/Data_Science/TGU_Proj/GitHub/School_21_Task_8/ml/d08_xgb_clf.sav'
}