import os
import os.path
import pickle
from cfg.config import settings
# ---------------------
from API.weather import Weather
from API.covid import COVID
from API.finance import Finance


# ---------------------

class PredictCur():

    def get_data_api(self):
        w = Weather('Москва')
        c = COVID()  # 'history'
        f = Finance()

        temper = w.get_data()
        covid = c.get_data()
        usd = f.get_data()

        return temper, covid, usd

    def get_data_ML(self, temper, covid, usd):
        temp_y = temper['yesterday']['temp']
        cases_y = covid['Russia']['All']['confirmed']
        deaths_y = covid['Russia']['All']['deaths']
        moscow_cases_y = covid['Russia']['Moscow']['confirmed']
        moscow_deaths_y = covid['Russia']['Moscow']['deaths']
        curs_y = usd['USD']['Previous']

        X_test = [[
            temp_y,
            cases_y,
            deaths_y,
            moscow_cases_y,
            moscow_deaths_y,
            curs_y
        ]]
        return X_test

    def forecast(self, X_test):
        # Загрузить сохранённую модель
        path_model = os.getcwd() + '/ml/d08_xgb_clf.sav'
        # path_model = settings['path_model']

        print(path_model)
        model = pickle.load(open(path_model, 'rb'))

        # получаем прогноз
        y_pred = model.predict_proba(X_test)  # вероятности класса
        y_pred1 = model.predict(X_test)  # класс спрогнозированный моделью

        return y_pred1

# pc = PredictCur()
# temper,covid,usd = pc.get_data_api()
# pprint(temp_y)
# pprint(cases_y)
# pprint(deaths_y)
# pprint(moscow_cases_y)
# pprint(moscow_deaths_y)
# pprint(curs_y)
# print('Вероятность падения курса: ', y_pred[0][0])
# print('Вероятность того что курс не упадет: ', y_pred[0][1])
# print('Прогноз модели: ', y_pred1)
# print(df.target.unique())
# df.to_csv('D:/0Dev/Data_Science/TGU_Proj/GitHub/School_21_Task_8/dataset.csv', index=False)
