import discord
from discord import Button, ButtonStyle
# ----------------------------
from bot.myBot import MyBot
from API.image import Image
from API.weather import Weather
from API.covid import COVID
from API.finance import Finance
from helpers.others import get_data, update_history, history_path
from helpers.embed import embed

# ----------------------------
# Создаем объект бота
# ----------------------------
bot = MyBot(command_prefix='.', intents=discord.Intents.all())


# ----------------------------
# Команды боту
# ----------------------------
# ----------------------------
# @bot.event
# async def on_message(message):
#     CMND = ["данные", "прогноз"]
#     if message.content.lower() in CMND:
#         await message.channel.send('oops')
#     await bot.process_commands(message)

@bot.command()
async def test(ctx):
    pass
    # await ctx.send(COVID().get_history())


@bot.command()
async def данные(ctx):
    data = get_data()
    await embed(ctx.message, data)


@bot.command()
async def прогноз(ctx):
    # data = get_data()
    data=bot.rate_pred
    await embed(ctx, data)


@bot.command()
async def погода(ctx, city='Москва'):
    weather = Weather(city)
    await ctx.send(f'Температура воздуха в городе {city} {weather.get_temperature()}°C')


@bot.command()
async def ковид(ctx, country="Russia"):
    Covid = COVID(country)
    await ctx.send(f'В стране {country} {Covid.get_cases()} случая заболевания ковидом')


@bot.command()
async def курс(ctx, currency='USD'):
    rate = Finance(currency)
    await ctx.send(f'Текущий курс {rate.currency}: {rate.get_rate()} руб.')
    await фото(ctx, 'Money')

@bot.command()
async def фото(ctx, collections=None):
    title = collections if collections else "Random image"
    embed = discord.Embed(color=0xff9900, title=title)
    url = await Image().get_image_url(collections)
    embed.set_image(url=url)
    await ctx.send(embed=embed)

@bot.command()
async def перезагрузка(ctx):
    embed = discord.Embed(color = 0xff9900, title = f'Пользователь {ctx.author} был успешно перезапущен')
    await ctx.send(embed = embed)

@bot.command()
async def деньги(ctx):
   msg_with_buttons = await ctx.send('Выберите валюту:', components=[[
       Button(label="USD",
              custom_id="USD",
              style=ButtonStyle.red),
       Button(label="EUR",
              custom_id="EUR",
              style=ButtonStyle.green),
       Button(label="JPY",
              custom_id="JPY",
              style=ButtonStyle.red)],[
       Button(label="GBP",
              custom_id="GBP",
              style=ButtonStyle.green),
       Button(label="AUD",
              custom_id="AUD",
              style=ButtonStyle.red),
       Button(label="CAD",
              custom_id="CAD",
              style=ButtonStyle.green)
   ]])

   def check_button(i: discord.Interaction, button):
       return i.author == ctx.author and i.message == msg_with_buttons

   interaction, button = await bot.wait_for('button_click', check=check_button, timeout=10)
   embed = discord.Embed(title=f'Вы выбрали {button.custom_id}',
   description=f'1 {button.custom_id}={Finance(button.custom_id).get_rate()} RUB', color=discord.Color.random())
   embed.set_thumbnail(url = 'https://www.alltime.ru/obj/article/image-blog/kakie_bivaut_probi_zolota/kakie_bivaut_probi_zolota.jpg')
   await interaction.respond(embed=embed)


@bot.command()
async def старт(ctx):
    hello_embed=discord.Embed(
        color = 0xfc0fc0,
        title = "Вот, что я умею:"
    )
    msg_with_buttons = await ctx.send(embed=hello_embed, components=[[
       Button(label="Погода",
              custom_id="weather",
              style=ButtonStyle.red),
       Button(label="Текущий курс EUR",
              custom_id="rate",
              style=ButtonStyle.green),
       Button(label="COVID статистика",
              custom_id="covid",
              style=ButtonStyle.red)],[
       Button(label="Фото котенка",
              custom_id="kitten",
              style=ButtonStyle.green),
       Button(label="Предсказание курса USD",
              custom_id="prediction",
              style=ButtonStyle.red),
       Button(label="RESET",
              custom_id="reset",
              style=ButtonStyle.green)
    ]])

    def check_button(i: discord.Interaction, button):
       return i.author == ctx.author and i.message == msg_with_buttons
    while True:
        interaction, button = await bot.wait_for('button_click', check=check_button)

        if button.custom_id == 'weather':
            await погода(ctx)
        if button.custom_id == 'rate':
            await курс(ctx, 'EUR')
        if button.custom_id == 'covid':
            await ковид(ctx)    
        if button.custom_id == 'kitten':
            await фото(ctx, 'Kitten')
        if button.custom_id == 'prediction':
            await прогноз(ctx) 
        if button.custom_id == 'reset':
            await перезагрузка(ctx) 
        if interaction:
            await interaction.respond(embed=discord.Embed(
                color = 0xffffff,
                title = "Команда успешно выполнена"
            ))


