import os

import discord
from discord.ext import commands

from helpers.others import create_if_not_exists, file_name, get_data


class MyBot(commands.Bot):
    intents = discord.Intents.all()

    #    intents.message_content = True
    def __init__(
            self,
            command_prefix="!",
            case_insensitive=True,
            intents=intents
    ):
        super().__init__(
            command_prefix=command_prefix,
            case_insensitive=case_insensitive,
            intents=intents
        )
        self.command_prefix = command_prefix
        self.case_insensitive = case_insensitive
        self.intents = intents
        self.rate_pred = get_data()

    async def on_ready(self):
        print("Bot ready.")
        print(f'Имя бота: {self.user.name}')
        print(f'ID бота: {self.user.id}')
        print()
        # создание файла для хранения истории прогнозов
        # create_if_not_exists(file_name)
