import discord
from discord.utils import get
# ----------------------------
# ----------------------------
from API.image import Image
from helpers.others import date


# ----------------------------
# Создание красивого вывода информации 
async def embed(ctx, data):
    emd = discord.Embed(
        color=0xff9900,
        title="Данные",
        description=f"*Данные для модели машинного обучения на {date}*",
        timestamp=ctx.message.created_at
    )
    # ------------------------
    # emd.set_author(
    #     name=msg.author.display_name , 
    #     # url=" https:// ", 
    #     # icon_url= msg.author.avatar_url 
    #     )
    # ------------------------
    column1 = "Больных COVID по России"
    column2 = "Темперара воздуха в Москве"
    column3 = "Актуальный курс USD в рублях"
    column4 = "Прогноз курса USD на сегодня"

    emd.add_field(name=column1, value=data["COVID"], inline=True)
    emd.add_field(name=column2, value=data["T"], inline=True)
    emd.add_field(name=column3, value=data["USD"], inline=True)
    emd.add_field(name=column4, value=data["Predict"], inline=False)
    # ------------------------
    url_covid = await Image().get_image_url('Coronavirus COVID-19 pandemic')
    url_group = 'https://images.unsplash.com/photo-1592480859808-9c93f6e8218e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8bGFwdG9wfHx8fHx8MTY2MjQ2Njk2NQ&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=200'
    emd.set_image(url=url_covid)
    emd.set_thumbnail(url=url_group)
    # ------------------------
    emd.set_footer(text="Team: Anya (TL), Safia, Andrey, Dmitrii")
    # ------------------------
    await ctx.send(embed=emd)
