import datetime as dt
import json
import os

from API.covid import COVID
from API.finance import Finance
from API.weather import Weather
from ml.ML import PredictCur

# файл для сохранения истории прогнозов
file_name = "history.json"
history_path = os.getcwd() + '/' + file_name
# текущая дата (гггг-мм-дд)
date = str(dt.datetime.now().strftime("%Y.%m.%d"))


def predict_exchange_rate():
    pc = PredictCur()
    temper, covid, usd = pc.get_data_api()
    X_test = pc.get_data_ML(temper, covid, usd)
    prog = pc.forecast(X_test)
    return 'Курс не упадет' if prog[0] == 1 else 'Курс упадет'


def get_data():
    return {
        'COVID': COVID('Russia').get_cases(),
        'T': Weather('Москва').get_temperature(),
        'USD': Finance('USD').get_rate(),
        'Predict': predict_exchange_rate()
    }


def update_history(current_data, path):
    with open(path, 'r') as file:
        data = json.load(file)
        file.close()

    with open(path, 'w') as file:
        # data = json.load(file)
        data[date] = current_data
        json.dump(data, file, indent=4)
        file.close()


def create_if_not_exists(file_name):
    if not os.path.exists(file_name):
        with open(file_name, 'w') as file:
            file.write('{}')
            file.close()
        print(f'Создан файл {file_name}')
    else:
        print(f'Найден файл {file_name}')
    print()
