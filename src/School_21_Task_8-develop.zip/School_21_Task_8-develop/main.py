from bot.methods import bot
from cfg.config import settings

bot.run(settings['token'])